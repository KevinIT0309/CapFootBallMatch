sap.ui.define([], () => {
    "use strict";

    return {
        determineSaveButtonStatus: function (team1_score, team2_score, match_time) {    
            let matchDate = new Date(match_time);
            let instant = new Date();

            if (isNaN(parseInt(team1_score)) || isNaN(parseInt(team2_score))) {
                return false;
            }

            if (matchDate.getTime() < instant.getTime()) {
                return true;
            }

            return false;
        }
    };
});