sap.ui.define([],()=>{"use strict";return{}});
//# sourceMappingURL=formatter.js.map