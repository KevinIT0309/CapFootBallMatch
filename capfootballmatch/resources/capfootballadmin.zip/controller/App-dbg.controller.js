sap.ui.define(
  [
    "cap/euro/admin/football/controller/BaseController"
  ],
  function (BaseController) {
    "use strict";

    return BaseController.extend("cap.euro.admin.football.controller.App", {
      onInit: function () {
      }
    });
  }
);
