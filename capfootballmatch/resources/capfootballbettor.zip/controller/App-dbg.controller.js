sap.ui.define(
    [
      "cap/euro/bettor/soccer/controller/BaseController"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("cap.euro.bettor.soccer.controller.App", {
        onInit: function() {
        }
      });
    }
  );
  