sap.ui.define([],()=>{"use strict";return{formatResultText:function(e,t){if(!isNaN(parseInt(e))&&!isNaN(parseInt(t))){return`${e} : ${t}`}else{return"N/A"}}}});
//# sourceMappingURL=formatter.js.map